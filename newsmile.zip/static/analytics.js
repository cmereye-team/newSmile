// G-XXXXXXXXXX 为自己生成的 Google Analytics 项目的ID
window.dataLayer = window.dataLayer || [];
function gtag() {
  dataLayer.push(arguments);
}
gtag("js", new Date());

gtag("config", "G-FN8KFBR9XM"); 

