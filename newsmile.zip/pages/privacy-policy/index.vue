<template>
  <div>
    <Header />
    <Navbar />
    <div class="page_container box">
      <div class="flex justify-center md:mt-28 mt-10">
        <h2>私隱政策</h2>
      </div>
      <p class="pb-4">
        以下是希瑪眼科醫療控股有限公司與其附屬公司根據《個人資料(私隱)條例》(第486章)之規定所訂之私隱政策聲明。我們將確保我們之職員將執行有關政策，嚴格保密你的個人資料。
      </p>
      <p class="pb-4">
        任何個人資料的收集將按本集團的《個人資料收集聲明》的條款所進行。個人資料將會安全穩妥儲存於我們的系統內，而本集團將採取所有切實可行的步驟，以確保個人資料的保存時間不超過將其保存以貫徹該資料被使用於或會被使用於的目的（包括任何直接有關的目的）所需的時間。只有經培訓及獲授權的職員才可獲准查閱該等個人資料，除《個人資料收集聲明》所載之人士除外，我們不會向任何本集團以外的人士發佈該等個人資料，用戶有權根據載於《個人資料收集聲明》的程序，要求存取及更正其個人資料。
      </p>
      <p class="pb-4">
        惟在法律准許的情況下，希瑪眼科醫療控股有限公司不會負責任何因以下情況而引致的損失、損毀或責任（不論直接或間接產生），包括但不限於收入、利潤或信譽的損失：(1)
        任何因電腦、網路、電話、技術或系統的不正常運作或其他問題，包括由電腦系統病毒感染、缺陷、篡改、未經授權的干擾、欺詐、技術故障或其他超出了希瑪眼科醫療控股有限公司的控制範圍的任何原因；(2)
        任何由第三者所提供的服務的缺乏或不足之處；(3)
        任何因資料傳送上的錯誤而導致通知的誤傳、延誤、更改或遺失。
        客戶亦需確保所有登記資料均為真實、準確及完整的資料，以及沒有冒用或盜用任何第三者之資料。如客戶因冒用或盜用任何第三者之資料而引致希瑪眼科醫療控股有限公司或其他第三者有任何損害，客戶須負上一切相關損失、損毀或責任，並對希瑪眼科醫療控股有限公司或其他第三者因此所承受的任何損害作出彌償及使其免於損害。
      </p>
      <p class="pb-4">
        本集團可不時根據用戶之個人資料向他們寄出宣傳產品及服務之直接市場推廣訊息。在直接市場推廣過程中，我們將提供適當之「拒絕服務選擇」。
      </p>
      <p class="pb-4">
        本集團將竭盡所能，確保用戶之私隱獲得妥善保障。然而，鑑於互聯網之性質，我們不能擔保可以做到「完全保障」。
      </p>
      <p class="pb-4">
        本集團會起用第三者內容供應商及服務供應商，並提供接駁其他網站之連結。此等第三者可於用戶使用其服務時收集有關用戶之個人資料。此等第三者將依其私隱政策行事，而我們的《私隱政策聲明》及《個人資料收集聲明》並不涵蓋該等第三者。
      </p>
      <p class="pb-4">
        用戶如對我們之私隱政策及慣例有任何疑問，請電郵<a
          style="color: #25395e"
          href=" mailto:marketing@cmereye.com"
          >marketing@cmereye.com</a
        >致希瑪眼科醫療控股有限公司。
      </p>
      <p class="pb-4"><span class="text-blue">個人資料收集聲明</span></p>
      <p class="pb-4">
        本聲明乃遵照《個人資料(私隱)條例》(第486章)的要求而發出，通知閣下收集資料的目的、閣下同意我們如何使用這些資料及閣下的權利。本聲明會不時更改，故請定期查閱。閣下登記使用我們之服務及每次登入我們網站，即表示同意接受當時生效之個人資料收集聲明。
      </p>
      <p class="pb-4"><span class="text-blue">資料之目的及用途</span></p>
      <p class="pb-4">我們所收集之資料將用作以下用途：</p>
      <p class="pb-4">· 監控本網站之運作及協助本網站之未來發展；</p>
      <p class="pb-4">
        · 匯編有關我們之用戶之整體統計資料以作關於網站使用的分析；
      </p>
      <p class="pb-4">· 識別和核實使用本網站所提供服務的用戶的身份；</p>
      <p class="pb-4">
        · 就有關或因使用本網站上所提供的服務發生的事項與用戶溝通；
      </p>
      <p class="pb-4">
        我們有意使用閣下的姓名、聯繫資料和任何與可能感興趣的商品和服務有關的資料，提供閣下可能有興趣的資訊，包括有針對性的橫幅廣告、新服務和產品和其他優惠並進行直接促銷。我們還有意而閣下亦同意，為上述目的轉移和提供上述資料予在香港以內和以外我們的附屬公司和協助本集團為閣下提供各項產品、設施、服務及其他優惠、獎賞或其他得益的供應商。如無閣下的同意，我們則不能如上使用或向該些機構提供上述資料。閣下可在向我們網站提供資料時表示同意，或以書面向我們表示同意，不另收費。
      </p>
      <p class="pb-4"><span class="text-blue">資料之轉移</span></p>
      <p>
        除了為上述目的使用有關資料時，合理而有需要把有關資料轉移予的相關人仕及機構外，我們不會以可識別閣下之方式向任何其他人士披露或傳遞閣下之資料。
      </p>
      <p class="pb-4"><span class="text-blue">資料之查閱</span></p>
      <p class="pb-4">
        閣下有權根據《個人資料（私隱）條例》(第486章)的規定，要求查閱或更正閣下之個人資料。如有任何查閱或更正資料的要求，請電郵至<a
          style="color: #25395e"
          href=" mailto:marketing@cmereye.com"
          >marketing@cmereye.com</a
        >。 此乃中文譯本，如有任何爭議，一切以英文為準。
      </p>
      <p class="pb-4">
        希瑪眼科醫療控股有限公司保留隨時更改、刪除或補充此條款及細則之權利，而不作另行通知。
      </p>
      <p class="pb-4">
        希瑪眼科醫療控股有限公司感謝貴客戶長期支持，我們不時與貴客戶分享希瑪眼科醫療控股有限公司的各種最新資訊。如貴客戶不願意收取希瑪眼科醫療控股有限公司的直接促銷材料及/或資訊，可以電郵至：<a
          style="color: #25395e"
          href=" mailto:marketing@cmereye.com"
          >marketing@cmereye.com</a
        >。
      </p>
      <p class="pb-24">此乃中文譯本，如有任何爭議，一切以英文為準。</p>
    </div>
    <Footer />
    <footers />
  </div>
</template>

<script>
import Header from "@/components/commom/head/Header.vue";
import Navbar from "@/components/commom/head/Navbar.vue";
import Footer from "@/components/commom/foot/Footer.vue";
import footers from "@/components/commom/foot/footers.vue";

export default {
  components: { Header, Navbar, Footer, footers },
  head() {
    return {
      title: "私隱政策 - 香港希瑪微笑矯視中心",
      meta: [
        {
          hid: "description",
          name: "description",
          content: "以下是希瑪眼科醫療控股有限公司與其附屬公 […]",
        },
        {
          hid: "keywords",
          name: "keywords",
          content: "以下是希瑪眼科醫療控股有限公司與其附屬公 […]",
        },
      ],
    };
  },
};
</script>

<style lang="scss" scoped>
h2 {
  font-size: 19px;
}
@media only screen and (max-width: 768px) {
  p {
    font-size: 15px;
  }
}
@media only screen and (min-width: 768px) {
  p {
    font-size: 16px;
  }
}
.text-blue {
  color: #25395e;
  font-size: 22px;
}
.box {
  padding: 0;
}
.section.vedio_box {
  margin-top: 0;
}
</style>
