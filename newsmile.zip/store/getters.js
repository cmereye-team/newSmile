const getters = {
  windowHeight: state => state.app.windowHeight
}
export default getters
