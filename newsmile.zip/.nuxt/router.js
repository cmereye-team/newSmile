import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _c53ca050 = () => interopDefault(import('..\\pages\\booking\\index.vue' /* webpackChunkName: "pages/booking/index" */))
const _255188c7 = () => interopDefault(import('..\\pages\\charge-detail\\index.vue' /* webpackChunkName: "pages/charge-detail/index" */))
const _82495156 = () => interopDefault(import('..\\pages\\consumption-voucher\\index.vue' /* webpackChunkName: "pages/consumption-voucher/index" */))
const _ffcc9350 = () => interopDefault(import('..\\pages\\contact-us\\index.vue' /* webpackChunkName: "pages/contact-us/index" */))
const _3b0f9a71 = () => interopDefault(import('..\\pages\\contactus000\\index.vue' /* webpackChunkName: "pages/contactus000/index" */))
const _74d72228 = () => interopDefault(import('..\\pages\\disclaimer\\index.vue' /* webpackChunkName: "pages/disclaimer/index" */))
const _660c942c = () => interopDefault(import('..\\pages\\eye-checkup\\index.vue' /* webpackChunkName: "pages/eye-checkup/index" */))
const _4d455136 = () => interopDefault(import('..\\pages\\flow-of-vision-correction\\index.vue' /* webpackChunkName: "pages/flow-of-vision-correction/index" */))
const _68c10377 = () => interopDefault(import('..\\pages\\free\\index.vue' /* webpackChunkName: "pages/free/index" */))
const _e61508e2 = () => interopDefault(import('..\\pages\\FreQuestions\\index.vue' /* webpackChunkName: "pages/FreQuestions/index" */))
const _09950556 = () => interopDefault(import('..\\pages\\group-profile\\index.vue' /* webpackChunkName: "pages/group-profile/index" */))
const _8d8d7da6 = () => interopDefault(import('..\\pages\\media\\index.vue' /* webpackChunkName: "pages/media/index" */))
const _7589bc7f = () => interopDefault(import('..\\pages\\medical-equipment\\index.vue' /* webpackChunkName: "pages/medical-equipment/index" */))
const _f0f98aae = () => interopDefault(import('..\\pages\\our-medical-team\\index.vue' /* webpackChunkName: "pages/our-medical-team/index" */))
const _cd655fa6 = () => interopDefault(import('..\\pages\\patient-info\\index.vue' /* webpackChunkName: "pages/patient-info/index" */))
const _07e69d60 = () => interopDefault(import('..\\pages\\post-corrective-care\\index.vue' /* webpackChunkName: "pages/post-corrective-care/index" */))
const _102aaaac = () => interopDefault(import('..\\pages\\privacy-policy\\index.vue' /* webpackChunkName: "pages/privacy-policy/index" */))
const _7f1aaf94 = () => interopDefault(import('..\\pages\\video\\index.vue' /* webpackChunkName: "pages/video/index" */))
const _e351bf2e = () => interopDefault(import('..\\pages\\vision-correction-icl\\index.vue' /* webpackChunkName: "pages/vision-correction-icl/index" */))
const _0e83cebb = () => interopDefault(import('..\\pages\\vision-correction-lasik\\index.vue' /* webpackChunkName: "pages/vision-correction-lasik/index" */))
const _c0c0968e = () => interopDefault(import('..\\pages\\vision-correction-presbyopia\\index.vue' /* webpackChunkName: "pages/vision-correction-presbyopia/index" */))
const _87c9feba = () => interopDefault(import('..\\pages\\about-us\\centre-introduction\\index.vue' /* webpackChunkName: "pages/about-us/centre-introduction/index" */))
const _3bb4b79d = () => interopDefault(import('..\\pages\\about-us\\medical-equipment\\index.vue' /* webpackChunkName: "pages/about-us/medical-equipment/index" */))
const _193300cc = () => interopDefault(import('..\\pages\\about-us\\medical-team\\index.vue' /* webpackChunkName: "pages/about-us/medical-team/index" */))
const _2de2cd4e = () => interopDefault(import('..\\pages\\Notice\\eyeExam\\index.vue' /* webpackChunkName: "pages/Notice/eyeExam/index" */))
const _7c7e3022 = () => interopDefault(import('..\\pages\\Notice\\Followdiag\\index.vue' /* webpackChunkName: "pages/Notice/Followdiag/index" */))
const _55bf8da0 = () => interopDefault(import('..\\pages\\Notice\\techProcess\\index.vue' /* webpackChunkName: "pages/Notice/techProcess/index" */))
const _239c82bb = () => interopDefault(import('..\\pages\\ophthalmicInfo\\AppointForm\\index.vue' /* webpackChunkName: "pages/ophthalmicInfo/AppointForm/index" */))
const _fe44e824 = () => interopDefault(import('..\\pages\\ophthalmicInfo\\mediaCov\\index.vue' /* webpackChunkName: "pages/ophthalmicInfo/mediaCov/index" */))
const _8bc704be = () => interopDefault(import('..\\pages\\ophthalmicInfo\\serveYyue\\index.vue' /* webpackChunkName: "pages/ophthalmicInfo/serveYyue/index" */))
const _c0a9432e = () => interopDefault(import('..\\pages\\ophthalmicInfo\\shareVideos\\index.vue' /* webpackChunkName: "pages/ophthalmicInfo/shareVideos/index" */))
const _506e9662 = () => interopDefault(import('..\\pages\\service\\CLEAR_Vision\\index.vue' /* webpackChunkName: "pages/service/CLEAR_Vision/index" */))
const _5c5d0234 = () => interopDefault(import('..\\pages\\service\\ICL\\index.vue' /* webpackChunkName: "pages/service/ICL/index" */))
const _d369f410 = () => interopDefault(import('..\\pages\\service\\LASIK\\index.vue' /* webpackChunkName: "pages/service/LASIK/index" */))
const _06acd13a = () => interopDefault(import('..\\pages\\service\\relex_smile\\index.vue' /* webpackChunkName: "pages/service/relex_smile/index" */))
const _f40f14c2 = () => interopDefault(import('..\\pages\\vision-correction\\relex-smile\\index.vue' /* webpackChunkName: "pages/vision-correction/relex-smile/index" */))
const _20160dbe = () => interopDefault(import('..\\pages\\charge-detail\\components\\Navbar.vue' /* webpackChunkName: "pages/charge-detail/components/Navbar" */))
const _1913471e = () => interopDefault(import('..\\pages\\free\\components\\Navbar.vue' /* webpackChunkName: "pages/free/components/Navbar" */))
const _3b5abfa3 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/booking",
    component: _c53ca050,
    name: "booking"
  }, {
    path: "/charge-detail",
    component: _255188c7,
    name: "charge-detail"
  }, {
    path: "/consumption-voucher",
    component: _82495156,
    name: "consumption-voucher"
  }, {
    path: "/contact-us",
    component: _ffcc9350,
    name: "contact-us"
  }, {
    path: "/contactus000",
    component: _3b0f9a71,
    name: "contactus000"
  }, {
    path: "/disclaimer",
    component: _74d72228,
    name: "disclaimer"
  }, {
    path: "/eye-checkup",
    component: _660c942c,
    name: "eye-checkup"
  }, {
    path: "/flow-of-vision-correction",
    component: _4d455136,
    name: "flow-of-vision-correction"
  }, {
    path: "/free",
    component: _68c10377,
    name: "free"
  }, {
    path: "/FreQuestions",
    component: _e61508e2,
    name: "FreQuestions"
  }, {
    path: "/group-profile",
    component: _09950556,
    name: "group-profile"
  }, {
    path: "/media",
    component: _8d8d7da6,
    name: "media"
  }, {
    path: "/medical-equipment",
    component: _7589bc7f,
    name: "medical-equipment"
  }, {
    path: "/our-medical-team",
    component: _f0f98aae,
    name: "our-medical-team"
  }, {
    path: "/patient-info",
    component: _cd655fa6,
    name: "patient-info"
  }, {
    path: "/post-corrective-care",
    component: _07e69d60,
    name: "post-corrective-care"
  }, {
    path: "/privacy-policy",
    component: _102aaaac,
    name: "privacy-policy"
  }, {
    path: "/video",
    component: _7f1aaf94,
    name: "video"
  }, {
    path: "/vision-correction-icl",
    component: _e351bf2e,
    name: "vision-correction-icl"
  }, {
    path: "/vision-correction-lasik",
    component: _0e83cebb,
    name: "vision-correction-lasik"
  }, {
    path: "/vision-correction-presbyopia",
    component: _c0c0968e,
    name: "vision-correction-presbyopia"
  }, {
    path: "/about-us/centre-introduction",
    component: _87c9feba,
    name: "about-us-centre-introduction"
  }, {
    path: "/about-us/medical-equipment",
    component: _3bb4b79d,
    name: "about-us-medical-equipment"
  }, {
    path: "/about-us/medical-team",
    component: _193300cc,
    name: "about-us-medical-team"
  }, {
    path: "/Notice/eyeExam",
    component: _2de2cd4e,
    name: "Notice-eyeExam"
  }, {
    path: "/Notice/Followdiag",
    component: _7c7e3022,
    name: "Notice-Followdiag"
  }, {
    path: "/Notice/techProcess",
    component: _55bf8da0,
    name: "Notice-techProcess"
  }, {
    path: "/ophthalmicInfo/AppointForm",
    component: _239c82bb,
    name: "ophthalmicInfo-AppointForm"
  }, {
    path: "/ophthalmicInfo/mediaCov",
    component: _fe44e824,
    name: "ophthalmicInfo-mediaCov"
  }, {
    path: "/ophthalmicInfo/serveYyue",
    component: _8bc704be,
    name: "ophthalmicInfo-serveYyue"
  }, {
    path: "/ophthalmicInfo/shareVideos",
    component: _c0a9432e,
    name: "ophthalmicInfo-shareVideos"
  }, {
    path: "/service/CLEAR_Vision",
    component: _506e9662,
    name: "service-CLEAR_Vision"
  }, {
    path: "/service/ICL",
    component: _5c5d0234,
    name: "service-ICL"
  }, {
    path: "/service/LASIK",
    component: _d369f410,
    name: "service-LASIK"
  }, {
    path: "/service/relex_smile",
    component: _06acd13a,
    name: "service-relex_smile"
  }, {
    path: "/vision-correction/relex-smile",
    component: _f40f14c2,
    name: "vision-correction-relex-smile"
  }, {
    path: "/charge-detail/components/Navbar",
    component: _20160dbe,
    name: "charge-detail-components-Navbar"
  }, {
    path: "/free/components/Navbar",
    component: _1913471e,
    name: "free-components-Navbar"
  }, {
    path: "/",
    component: _3b5abfa3,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
