export { default as CommomFootFooter } from '../..\\components\\commom\\foot\\Footer.vue'
export { default as CommomFootFooters } from '../..\\components\\commom\\foot\\footers.vue'
export { default as CommomHeadBanner } from '../..\\components\\commom\\head\\Banner.vue'
export { default as CommomHeadHeader } from '../..\\components\\commom\\head\\Header.vue'
export { default as CommomHeadNavbar } from '../..\\components\\commom\\head\\Navbar.vue'
export { default as CommomSwiperMySwiper } from '../..\\components\\commom\\swiper\\MySwiper.vue'
export { default as ContentFreQuestionsFirstProblem } from '../..\\components\\content\\FreQuestions\\firstProblem.vue'
export { default as ContentFreQuestionsFourProblem } from '../..\\components\\content\\FreQuestions\\fourProblem.vue'
export { default as ContentFreQuestionsSecondProblem } from '../..\\components\\content\\FreQuestions\\secondProblem.vue'
export { default as ContentFreQuestionsThirtProblem } from '../..\\components\\content\\FreQuestions\\thirtProblem.vue'
export { default as ContentContactusBannerSlider } from '../..\\components\\content\\contactus\\BannerSlider.vue'
export { default as ContentContactusGoogleMap } from '../..\\components\\content\\contactus\\GoogleMap.vue'
export { default as ContentContactusServeTable } from '../..\\components\\content\\contactus\\ServeTable.vue'
export { default as ContentFreeTab } from '../..\\components\\content\\free\\tab.vue'
export { default as ContentEyeCheckup } from '../..\\components\\content\\eye-checkup\\index.vue'
export { default as ContentAboutusDoctorTeamBannerSlider } from '../..\\components\\content\\aboutus\\doctor-team\\BannerSlider.vue'
export { default as ContentAboutusDoctorTeamBossInfo } from '../..\\components\\content\\aboutus\\doctor-team\\BossInfo.vue'
export { default as ContentAboutusDoctorInfo } from '../..\\components\\content\\aboutus\\doctor-team\\DoctorInfo.vue'
export { default as ContentOphthalmicInfoConsumption } from '../..\\components\\content\\ophthalmicInfo\\consumption\\index.vue'
export { default as ContentAboutusEquipCenterBannerSlider } from '../..\\components\\content\\aboutus\\equip-center\\BannerSlider.vue'
export { default as ContentAboutusEquipInfo } from '../..\\components\\content\\aboutus\\equip-center\\EquipInfo.vue'
export { default as ContentAboutusCentreIntroductionHuanjswiper } from '../..\\components\\content\\aboutus\\centre-introduction\\huanjswiper.vue'
export { default as ContentAboutusCentreIntroductionSe1MainBanner } from '../..\\components\\content\\aboutus\\centre-introduction\\Se1MainBanner.vue'
export { default as ContentAboutusCentreIntroductionSe2ComIntro } from '../..\\components\\content\\aboutus\\centre-introduction\\Se2ComIntro.vue'
export { default as ContentAboutusCentreIntroductionSe3CentreInfor } from '../..\\components\\content\\aboutus\\centre-introduction\\Se3CentreInfor.vue'
export { default as ContentHomeAspiration } from '../..\\components\\content\\home\\aspiration.vue'
export { default as ContentHomeBannerSlider } from '../..\\components\\content\\home\\BannerSlider.vue'
export { default as ContentHomeCmerInfo } from '../..\\components\\content\\home\\CmerInfo.vue'
export { default as ContentHomeCorrectionService } from '../..\\components\\content\\home\\CorrectionService.vue'
export { default as ContentHomeInstagramSlider } from '../..\\components\\content\\home\\InstagramSlider.vue'
export { default as ContentHomeReservation } from '../..\\components\\content\\home\\Reservation.vue'
export { default as ContentHomeServe } from '../..\\components\\content\\home\\serve.vue'
export { default as ContentHomeVedioSlider } from '../..\\components\\content\\home\\VedioSlider.vue'
export { default as ContentServiceCLEARVisionBenefit } from '../..\\components\\content\\service\\CLEAR_Vision\\Benefit.vue'
export { default as ContentServiceCLEARVisionMainBanner } from '../..\\components\\content\\service\\CLEAR_Vision\\MainBanner.vue'
export { default as ContentServiceCLEARVisionManMade } from '../..\\components\\content\\service\\CLEAR_Vision\\manMade.vue'
export { default as ContentServiceCLEARVisionSuitable } from '../..\\components\\content\\service\\CLEAR_Vision\\suitable.vue'
export { default as ContentOphthalmicInfoServeYyueMainBanner } from '../..\\components\\content\\ophthalmicInfo\\serveYyue\\MainBanner.vue'
export { default as ContentOphthalmicInfoServe } from '../..\\components\\content\\ophthalmicInfo\\serveYyue\\serve.vue'
export { default as ContentOphthalmicInfoMediaCovMainBanner } from '../..\\components\\content\\ophthalmicInfo\\mediaCov\\MainBanner.vue'
export { default as ContentOphthalmicInfoMedia } from '../..\\components\\content\\ophthalmicInfo\\mediaCov\\media.vue'
export { default as ContentOphthalmicInfoShareVideosMainBanner } from '../..\\components\\content\\ophthalmicInfo\\shareVideos\\MainBanner.vue'
export { default as ContentOphthalmicInfoShareVideo } from '../..\\components\\content\\ophthalmicInfo\\shareVideos\\shareVideo.vue'
export { default as ContentServiceICLBenefit } from '../..\\components\\content\\service\\ICL\\Benefit.vue'
export { default as ContentServiceICLFilm } from '../..\\components\\content\\service\\ICL\\film.vue'
export { default as ContentServiceICLMainBanner } from '../..\\components\\content\\service\\ICL\\MainBanner.vue'
export { default as ContentServiceICLShare } from '../..\\components\\content\\service\\ICL\\share.vue'
export { default as ContentServiceICLSuitable } from '../..\\components\\content\\service\\ICL\\suitable.vue'
export { default as ContentNoticeFollowdiagFollowDiago } from '../..\\components\\content\\Notice\\Followdiag\\followDiago.vue'
export { default as ContentNoticeFollowdiagMainBanner } from '../..\\components\\content\\Notice\\Followdiag\\MainBanner.vue'
export { default as ContentNoticeFollowdiagPrecautions } from '../..\\components\\content\\Notice\\Followdiag\\precautions.vue'
export { default as ContentServiceRelexSmileBenefit } from '../..\\components\\content\\service\\relex_smile\\Benefit.vue'
export { default as ContentServiceRelexSmileFit } from '../..\\components\\content\\service\\relex_smile\\Fit.vue'
export { default as ContentServiceRelexSmileMainBanner } from '../..\\components\\content\\service\\relex_smile\\MainBanner.vue'
export { default as ContentServiceRelexSmileStep } from '../..\\components\\content\\service\\relex_smile\\Step.vue'
export { default as ContentServiceRelexSmileXtra } from '../..\\components\\content\\service\\relex_smile\\Xtra.vue'
export { default as ContentNoticeEyeTest } from '../..\\components\\content\\Notice\\eyeExam\\eyeTest.vue'
export { default as ContentNoticeEyeExamMainBanner } from '../..\\components\\content\\Notice\\eyeExam\\MainBanner.vue'
export { default as ContentNoticeEyeExamPreorthoptic } from '../..\\components\\content\\Notice\\eyeExam\\Preorthoptic.vue'
export { default as ContentServiceLASIKBenefit } from '../..\\components\\content\\service\\LASIK\\Benefit.vue'
export { default as ContentServiceLASIKMainBanner } from '../..\\components\\content\\service\\LASIK\\MainBanner.vue'
export { default as ContentServiceLASIKPrinciple } from '../..\\components\\content\\service\\LASIK\\principle.vue'
export { default as ContentServiceLASIKSuitable } from '../..\\components\\content\\service\\LASIK\\suitable.vue'
export { default as ContentNoticeTechProcessMainBanner } from '../..\\components\\content\\Notice\\techProcess\\MainBanner.vue'
export { default as ContentNoticeTechProcess } from '../..\\components\\content\\Notice\\techProcess\\process.vue'
export { default as ContentNoticeTechProcessRegard } from '../..\\components\\content\\Notice\\techProcess\\regard.vue'
export { default as ContentOphthalmicInfoServeYyueAppointFrom } from '../..\\components\\content\\ophthalmicInfo\\serveYyue\\AppointForm\\appointFrom.vue'
export { default as ContentOphthalmicInfoServeYyueAppointFormMainBanner } from '../..\\components\\content\\ophthalmicInfo\\serveYyue\\AppointForm\\MainBanner.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
